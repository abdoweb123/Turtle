
$(function () {
  $("#navBar").load("navBar.html");
  $("#navSlider").load("navslider.html");
  $("#icons").load("icons.html");
  $("#footer").load("Footer.html");
  $("#gray-footer").load("gray-footer.html");
  $("#sideNav").load("Sidenavbar.html");
});
$(document).ready(() => {
  $(".loading-screen").fadeOut(1000);
});
